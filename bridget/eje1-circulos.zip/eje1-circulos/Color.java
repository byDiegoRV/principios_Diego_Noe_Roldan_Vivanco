interface Color {
    void aplicar();
}